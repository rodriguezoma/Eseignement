<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
<?php	
require_once('Includes/header.php');
require_once('Includes/body.php');
require_once('Includes/footer.php');
?>
</body>
</html>