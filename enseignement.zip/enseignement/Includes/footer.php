<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
      <table width="100%" style="background-color: black;">
      	<tr>
      		<td width="80%">
      			<h3 style="color: white;">
      			     2021 Ministère de l’Education Nationale, de l’Alphabétisation et de la Promotion des Langues Nationales       
      		    </h3>
      		</td>
      		<td width="0.1%" style="background-color: white;"></td>
      		<td width="19.9%">
      			<h3><a href="#" style="color: white;">CONDITIONS D'UTILISATION</a></h3>
      		</td>
      	</tr>
      </table>
</body>
</html>